// Canonical character inventory for Elijah. Loaded directly by the browser generator.
const CHARACTER_PRESETS_META = {
  "story": "Elijah",
  "defaultPreset": "elijah",
  "groupLabel": "Elijah characters"
};
const ELIJAH_BASE = {
  "noseScale": 1,
  "noseShape": "straight",
  "eyeShape": "almond",
  "eyeSpacing": 1,
  "eyebrowStyle": "arched",
  "mouthStyle": "neutral",
  "hairStyle": "wavy",
  "beardStyle": "short",
  "hatStyle": "none",
  "clothingType": "tunic",
  "faceShape": "oval",
  "foreheadHeight": "medium",
  "chinShape": "rounded",
  "earSize": 1,
  "earShape": "round",
  "headSize": 1,
  "hairSize": 1,
  "hatSize": 1,
  "hatMatchHair": false,
  "dualStripe": false,
  "colorInner": "#c7a56a",
  "colorOuter": "#6f4c2d",
  "colorCloak": "#493321",
  "colorAccent": "#b78a3d",
  "colorGarment2": "#ddd0ad",
  "colorSkin": "#b9825d",
  "colorHair": "#2a1d16",
  "colorEye": "#3d2d24",
  "colorLip": "#985e50",
  "materialStyle": "woven_linen"
};
const elijahPreset = (name, overrides = {}) => ({ ...ELIJAH_BASE, name, ...overrides });
const CHARACTER_PRESETS_DATA = {
  "elijah": elijahPreset("Elijah", {"hairStyle":"short","hatStyle":"shepherd_wrap","clothingType":"desert_mantle","materialStyle":"herringbone","colorInner":"#d6b477","colorOuter":"#6f4b32","colorCloak":"#3f3027","colorAccent":"#c99b46","hatSize":0.9,"hairSize":0.9}),
  "ahab": elijahPreset("Ahab", {"clothingType":"royal_robes","colorOuter":"#365f67","colorAccent":"#d3ad53","dualStripe":true,"noseShape":"aquiline","eyebrowStyle":"thick","hairStyle":"shoulder_waves","hatStyle":"royal_diadem","materialStyle":"dotted","colorInner":"#b78d58","colorCloak":"#263f47","hatSize":1,"hairSize":1}),
  "jezebel": elijahPreset("Jezebel", {"beardStyle":"none","hairStyle":"crown_braids","hatStyle":"royal_diadem","faceShape":"square","chinShape":"square","colorSkin":"#9d6748","clothingType":"court_dress","materialStyle":"fine_linen","colorInner":"#d0aa78","colorOuter":"#77414b","colorCloak":"#4c2d36","colorAccent":"#c89749","hatSize":1.1,"hairSize":1.1}),
  "widow_of_zarephath": elijahPreset("Widow Of Zarephath", {"beardStyle":"none","hairStyle":"braids","hatStyle":"veil","colorOuter":"#53613a","clothingType":"work_tunic","materialStyle":"woven_linen","colorInner":"#c2a36b","colorCloak":"#354229","colorAccent":"#b99045","hatSize":0.9,"hairSize":1.2}),
  "widows_son": elijahPreset("Widows Son", {"beardStyle":"none","hairStyle":"side_braid","hatStyle":"veil","clothingType":"work_tunic","materialStyle":"woven_linen","colorInner":"#d8c39b","colorOuter":"#67547a","colorCloak":"#40364f","colorAccent":"#d0ad58","hatSize":1,"hairSize":0.9}),
  "obadiah": elijahPreset("Obadiah", {"noseShape":"aquiline","eyebrowStyle":"thick","hairStyle":"locs","hatStyle":"none","clothingType":"traveller_cloak","materialStyle":"tartan","colorInner":"#c1a178","colorOuter":"#875b34","colorCloak":"#533920","colorAccent":"#d0a34c","hatSize":1,"hairSize":1}),
  "prophet_of_baal": elijahPreset("Prophet Of Baal", {"faceShape":"square","chinShape":"square","colorSkin":"#9d6748","hairStyle":"shaved_sides","hatStyle":"shepherd_wrap","clothingType":"desert_mantle","materialStyle":"woven_linen","colorInner":"#d6b477","colorOuter":"#6f4b32","colorCloak":"#3f3027","colorAccent":"#c99b46","hatSize":0.9,"hairSize":1.1}),
  "elisha": elijahPreset("Elisha", {"hairStyle":"flowing","colorOuter":"#365f67","hatStyle":"hood","clothingType":"prophet_mantle","materialStyle":"herringbone","colorInner":"#b78d58","colorCloak":"#263f47","colorAccent":"#d3ad53","hatSize":1,"hairSize":1.2}),
  "naboth": elijahPreset("Naboth", {"hairStyle":"short","hatStyle":"skullcap","clothingType":"tunic","materialStyle":"herringbone","colorInner":"#d0aa78","colorOuter":"#77414b","colorCloak":"#4c2d36","colorAccent":"#c89749","hatSize":1.1,"hairSize":0.9}),
};
