# 07 — NPCs, Dialogue and Choices

## NPC Types
- family
- neighbours
- builders
- farmers
- children
- sceptics
- supporters
- traders

## Choices
Players can explain, ignore, joke, request assistance, disagree or reassure.

## Relationships
Track simple values such as trust, respect and willingness to help. Use these to alter dialogue and assistance rather than making every conversation a morality meter.

## Milestone
At least five NPCs have distinct reactions and remember player choices.
