# 03 — Player, World and Exploration

## Goal
Create the explorable farm and surrounding area.

## Areas
- Noah's home
- fields
- woodland
- river
- construction area
- animal area
- nearby settlement

## Exploration
Use landmarks rather than excessive waypoint arrows.

## Interaction Feedback
Approaching an interactive object should:
- highlight it
- show a prompt
- play a subtle sound
- support touch/controller equivalents

## Camera
Support third-person camera, smoothing, collision avoidance and mobile camera controls.

## Milestone
The player can explore the farm and find important locations without a map.
