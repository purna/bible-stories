# Noah — Vite Game Implementation Series

## Purpose
Master roadmap for building the interactive Noah game as a browser game using Vite and TypeScript.

## Technology
- Vite
- TypeScript
- HTML/CSS
- Three.js for 3D rendering
- GLB/GLTF assets
- Web Audio API or Howler.js
- JSON-driven game data
- localStorage/IndexedDB for saves

## Development Principles
1. Build a playable vertical slice first.
2. Separate data from code.
3. Keep systems modular.
4. Make story chapters playable rather than purely narrated.
5. Use environmental storytelling.
6. Support desktop and mobile.
7. Design accessibility from the start.
8. Make effects scalable for low-end devices.

## Stages
1. Project foundation
2. Core gameplay
3. Player and exploration
4. Story and narration
5. Ark construction and resources
6. Animal management
7. NPCs and dialogue
8. Countdown and flood
9. Post-flood restoration
10. Graphics
11. Audio
12. UI
13. UX
14. Post-processing
15. Save/progression
16. Accessibility
17. Performance
18. Testing/polish
19. Build/deployment

## Vertical Slice
Farm → Calling → Gather wood → Build first Ark section → Meet an animal → Talk to one NPC → Trigger weather event.
