# 20 — Development Backlog

## Phase 1 — Prototype
- [ ] Vite + TypeScript project
- [ ] player movement
- [ ] camera
- [ ] farm scene
- [ ] interaction
- [ ] timber collection
- [ ] first Ark stage
- [ ] basic narration
- [ ] one animal

## Phase 2 — Vertical Slice
- [ ] Calling sequence
- [ ] three Ark stages
- [ ] six animal species
- [ ] three NPCs
- [ ] dialogue choices
- [ ] resources
- [ ] weather
- [ ] basic audio
- [ ] final-style UI
- [ ] post-processing

## Phase 3 — Full Game
- [ ] complete Ark
- [ ] animal management
- [ ] NPC relationships
- [ ] seven-day countdown
- [ ] flood survival
- [ ] raven and dove
- [ ] post-flood world
- [ ] altar
- [ ] rainbow
- [ ] epilogue

## Phase 4 — Production
- [ ] final graphics
- [ ] animation
- [ ] music
- [ ] sound effects
- [ ] narration
- [ ] accessibility
- [ ] mobile optimisation
- [ ] save system
- [ ] testing
- [ ] deployment

## Rule
Complete each milestone as a playable increment before moving to the next major system.
