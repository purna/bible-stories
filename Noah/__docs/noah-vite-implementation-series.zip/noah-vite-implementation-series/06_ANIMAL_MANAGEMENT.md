# 06 — Animal Management

## Goal
Make caring for animals a major gameplay system.

## Animal Data
Each species can have:
- hunger
- thirst
- stress
- health
- space requirement
- preferred food
- temperament
- social needs
- enclosure requirements

## Examples
- Birds need perches and may escape.
- Goats climb and cause enclosure problems.
- Elephants consume large quantities of food and water.
- Lions become stressed near prey.
- Rabbits reproduce rapidly.
- Chickens produce eggs.

## Personality
Individual animals can be calm, nervous, aggressive, curious, friendly or stubborn.

## Milestone
At least six species behave differently rather than being reskinned collectibles.
