# 10 — Graphics and Art Pipeline

## Visual Direction
Recommended:
- stylised 3D
- simplified geometry
- expressive silhouettes
- warm natural environments
- readable materials
- strong chapter-to-chapter colour progression

## Assets
Terrain, Ark, buildings, tools, vegetation, rocks, animals, NPCs, props and VFX.

## Pipeline
Blender → GLB → optimisation → Three.js → material setup

## Rules
- consistent scale
- sensible origins
- controlled polygon budgets
- compressed textures
- reusable materials
- LODs

## Animation
First priority:
idle, walk, run, interact, carry, build, feed, repair and emotional reactions.

## Milestone
The farm and first Ark section use final-style placeholder graphics.
