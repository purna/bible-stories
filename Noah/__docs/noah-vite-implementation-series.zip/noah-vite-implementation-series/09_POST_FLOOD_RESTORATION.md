# 09 — Post-Flood Restoration

## Goal
Change the tone from survival to hope.

## Activities
- open animal gates
- explore new land
- clear debris
- plant crops
- build shelters
- collect materials
- establish food production
- rebuild community

## Animal Release
Opening each enclosure is interactive. Animals hesitate, then move into the new world.

## Altar
Gather materials and construct the altar before the covenant sequence.

## Milestone
The player transforms an empty landscape into the beginning of a settlement.
