# 13 — UX Design

## First-Time Experience
Teach through action:
1. Walk
2. Interact
3. Collect
4. Build
5. Care for an animal
6. Discover a story event

## Feedback
Important actions should use at least two feedback channels: visual, audio, animation, text or vibration.

## Failure
Prefer consequences such as damaged equipment, lost resources, stressed animals or delayed construction over frequent game-over states.

## Accessibility
- scalable text
- high contrast
- subtitles
- reduced motion
- colour-independent indicators
- remappable controls
- audio cues with visual equivalents

## Milestone
A new player reaches the first meaningful story event without external instructions.
