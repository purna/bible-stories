# 02 — Core Gameplay

## Core Loop
Explore → Interact → Collect → Decide → Build/Care → Story Event → Explore

## Player
- movement
- camera
- interaction range
- animation state
- optional stamina

## Interaction
Create reusable interactions for:
- inspect
- collect
- talk
- feed
- repair
- build
- open
- activate

## Game State
Track:
- chapter
- day
- objectives
- resources
- animals
- NPC relationships
- Ark construction
- weather
- story flags

## Milestone
The player can walk around a farm, interact with objects and complete an objective.
