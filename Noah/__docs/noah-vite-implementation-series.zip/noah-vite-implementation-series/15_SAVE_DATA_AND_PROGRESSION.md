# 15 — Save Data and Progression

## Store
- chapter
- objective
- day
- resources
- Ark construction
- animal states
- NPC relationships
- story flags
- settings

## Implementation
Use localStorage for early prototypes and IndexedDB if data becomes larger.

Version save data so future updates can migrate old saves.

## Milestone
Reloading the game restores meaningful progress.
