# 01 — Project Foundation

## Goal
Create a clean Vite + TypeScript project.

## Structure
```text
src/
  core/
  game/
    player/
    world/
    animals/
    npcs/
    crafting/
    resources/
    weather/
    flood/
  narrative/
  ui/
  audio/
  graphics/
  effects/
  data/
  save/
  accessibility/
  main.ts
public/assets/
  models/
  textures/
  audio/
  fonts/
```

## Initial Systems
- Game bootstrap
- Scene manager
- Game state manager
- Input manager
- Asset manager
- Audio manager
- UI manager
- Save manager
- Event bus

## Milestone
The application starts, shows the game scene, and can transition between title and gameplay.
