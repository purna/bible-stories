# 04 — Story and Interactive Narration

## Story Pattern
Gameplay → Story Event → Player Choice → Consequence → Gameplay

Avoid long exposition when the player can discover information through play.

## Chapters
### 1 — The Calling
Experience Noah's ordinary farm life before the calling.

### 2 — Building the Ark
Gather materials, construct sections and respond to people questioning the project.

### 3 — Gathering Animals
Animals arrive and must be organised and cared for.

### 4 — Seven-Day Countdown
Seven increasingly tense days lead to the rain.

### 5 — The Flood
Survival inside the Ark replaces open-world exploration.

### 6 — Raven and Dove
Release the birds and discover signs of dry land.

### 7 — New World
Release animals, restore land and build an altar.

### 8 — Covenant
Discover the rainbow naturally.

### Optional Epilogue
Noah's vineyard provides a reflective ending.

## Dialogue Data
Use JSON containing speaker, text, choices, conditions and consequences.

## Milestone
The early story is playable without dialogue hard-coded into gameplay classes.
