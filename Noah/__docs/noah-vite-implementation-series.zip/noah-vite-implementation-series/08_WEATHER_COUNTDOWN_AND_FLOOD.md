# 08 — Countdown, Weather and Flood

## Seven-Day Countdown
Day 1: normal.
Day 2: subtle weather changes.
Day 3: animals become unsettled.
Day 4: NPCs discuss unusual conditions.
Day 5: stronger wind and clouds.
Day 6: silence and tension.
Day 7: rain begins.

## Flood Gameplay
Do not treat the Ark as a conventional sailing vehicle. Focus on:
- leaks
- structural damage
- animal panic
- food
- water
- family tasks
- darkness
- storm sounds

## Task Assignment
Family members can handle feeding, repairs, water, animal care, storage and observation.

## Milestone
The flood is a playable survival chapter.
