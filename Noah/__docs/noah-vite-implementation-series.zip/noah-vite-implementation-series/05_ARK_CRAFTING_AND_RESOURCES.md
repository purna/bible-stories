# 05 — Ark Construction, Crafting and Resources

## Construction Stages
1. Foundation
2. Hull
3. Lower deck
4. Middle deck
5. Upper deck
6. Roof
7. Waterproofing
8. Food storage
9. Water storage
10. Animal pens

## Resources
- timber
- stone
- pitch
- rope
- food
- water
- seeds
- animal supplies

## Design
Every resource should solve a real problem. Avoid meaningless grinding.

Players can work harder, take shortcuts, ask for help, spend resources or postpone construction.

Shortcuts may create later consequences.

## Milestone
At least three Ark stages can be constructed and visibly change the world.
