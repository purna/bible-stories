# 11 — Audio Design

## Music Themes
- ordinary farm
- calling
- construction
- animal care
- countdown
- storm
- flood
- hope
- restoration
- covenant

## Dynamic Music
Intensity responds to weather, danger, animal panic, story events and location.

## Sound Effects
Footsteps, wood, tools, hammering, animals, water, rain, thunder, wind, Ark creaks and UI sounds.

## Voice
Start with text narration and add voice-over later if desired.

## Milestone
Major gameplay states are recognisable through audio.
