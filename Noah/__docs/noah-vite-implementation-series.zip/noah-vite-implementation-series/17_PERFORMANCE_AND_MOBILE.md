# 17 — Performance and Mobile

## Techniques
- texture compression
- GLB optimisation
- LOD
- instancing
- object pooling
- frustum culling
- limited dynamic lights
- efficient particles
- lazy loading
- scene streaming where needed

## Quality Levels
### Low
Minimal shadows, reduced particles, reduced post-processing and lower texture resolution.

### Medium
Balanced default.

### High
Improved shadows, more particles, higher textures and richer atmosphere.

## Milestone
The first chapter performs well on a representative low-end mobile device.
