# 12 — UI Design

## Goal
Keep the interface readable without obscuring the world.

## HUD
Show only immediate information:
- objective
- interaction prompt
- selected resource
- important animal warning
- day/weather state when relevant

## Menus
- pause
- inventory
- animals
- Ark construction
- map
- dialogue
- settings
- save/load

## Mobile
Support virtual movement, touch interaction, camera swipe and large action buttons.

## Milestone
Players can understand what to do next without a long tutorial.
