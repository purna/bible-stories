# 16 — Accessibility

## Visual
Scalable UI, readable fonts, contrast settings, colour-blind-safe indicators and reduced visual effects.

## Hearing
Subtitles, captions, visual storm warnings and visual equivalents for animal distress.

## Motor
Remapping, hold/toggle options and reduced precision requirements.

## Cognitive
Optional objective reminders, consistent interaction language, predictable menus and adjustable tutorial support.

## Milestone
Critical gameplay information does not depend on a single sensory channel.
