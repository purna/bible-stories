# 18 — Testing and Polish

## Functional Tests
Movement, interaction, inventory, construction, animal needs, dialogue, choices, story flags, weather, flood, saves, UI and audio.

## Narrative Tests
Ensure events trigger correctly, choices have intended consequences and optional activities cannot permanently block progression.

## Browser Tests
Chrome, Edge, Firefox, Safari, Android browsers and iOS Safari.

## Polish Order
1. animation
2. sound
3. lighting
4. VFX
5. UI transitions
6. camera
7. environment
8. performance

## Milestone
A complete playthrough is possible without critical bugs.
