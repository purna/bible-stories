# 19 — Build, Deployment and Release

## Development
```bash
npm install
npm run dev
```

## Production
```bash
npm run build
npm run preview
```

## Release Checklist
- production build succeeds
- no TypeScript errors
- assets load
- saves work
- mobile layout works
- audio works
- accessibility works
- performance tested
- version updated

## Deployment
Suitable static hosts include GitHub Pages, Netlify, Vercel and Cloudflare Pages.

## Milestone
A production build can be deployed without manual source changes.
