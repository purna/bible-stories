# 14 — Post Processing and Atmosphere

## Farm
Soft lighting, subtle fog and gentle colour grading.

## Calling
Reduced environmental sound, subtle bloom, controlled exposure and increased atmospheric depth.

## Countdown
Darker skies, cloud density, stronger shadows and wind.

## Storm
Rain, fog, exposure changes and lightning flashes.

## Post-Flood
Brighter exposure, warm sunlight and softer haze.

## Rainbow
Restrained bloom and colour separation so the moment feels special without becoming noisy.

## Performance
Every effect should have quality settings and mobile fallbacks. Prefer lightweight shader effects over expensive full-screen effects.

## Milestone
Each chapter has a recognisable atmosphere before narration or UI is read.
